package parse;

import java.util.ArrayList;
import java.util.Arrays;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
 
 
public class SaxHandler1 extends DefaultHandler {
	private ArrayList<String> animeList = new ArrayList<>();
	boolean inName = false;
	
    @Override
    public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
    	if (inName) {
    		String name = new String(arg0, arg1, arg2);
    		animeList.add(name);
    	}
    }
 
    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }
    
    @Override
    public void endDocument() throws SAXException {
    	super.endDocument();
    	String[] animes = (String[])animeList.toArray(new String[animeList.size()]);
    	Arrays.sort(animes);
    	for(int i = 0; i < animes.length; i++) {
			System.out.println(i+1 + "." + animes[i]);
		}
    }
 
    @Override
    public void startElement(String arg0, String arg1, String arg2,
            Attributes arg3) throws SAXException {
        if (arg2 == "name" && (arg3.getLength() == 0 || arg3.getValue("language").equals("Chinese"))) {
        	inName = true;
        }
        super.startElement(arg0, arg1, arg2, arg3);
    }
    
    @Override
    public void endElement(String arg0, String arg1, String arg2)
            throws SAXException {
    	if (inName) {
			inName = !inName;
		}
        super.endElement(arg0, arg1, arg2);
    }
}