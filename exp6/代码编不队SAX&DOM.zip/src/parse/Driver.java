package parse;

import java.io.File;
import java.util.Scanner;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
 
 
public class Driver {
    public static void main(String[] args) throws Exception {
    	System.out.println("(遇中文乱码请运行源码)\n1.名称排序\n2.集数排序\n3.估价排序\n4.查询集数过半\n5.查询非第一季\n6.查询周更\n7.重建Xml");
    	Scanner scan = new Scanner(System.in);
    	System.out.println("输入文件路径：");
    	String path = scan.nextLine();
    	System.out.println("选择操作选项：");
    	int selected = scan.nextInt();
        // 1.实例化SAXParserFactory对象
        SAXParserFactory factory = SAXParserFactory.newInstance();
        // 2.创建解析器
        SAXParser parser = factory.newSAXParser();
        // 3.获取需要解析的文档，生成解析器,最后解析文档
        File f = new File(path);
        switch (selected) {
		case 1:
	        parser.parse(f, new SaxHandler1());
			break;
		case 2:
			parser.parse(f, new SaxHandler2());
			break;
		case 3:
			parser.parse(f, new SaxHandler3());
			break;
		case 4:
			parser.parse(f, new SaxHandler4());
			break;
		case 5:
			parser.parse(f, new SaxHandler5());
			break;
		case 6:
			parser.parse(f, new SaxHandler6());
			break;
		case 7:
			DomRemake.domRemake(path);
			break;

		default:
			break;
		}
        scan.close();
    }
}