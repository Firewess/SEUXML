package parse;

import java.util.ArrayList;
import java.util.Arrays;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class SaxHandler5 extends DefaultHandler {	
	class anime3 implements Comparable{
		String name;
		int price;
		anime3(String x, int y){
			this.name = x;
			this.price = y;
		}
		@Override
		public int compareTo(Object o) {
			anime3 obj = (anime3) o;
			return price - obj.price;
		}
		public String toString(){
			return name + " : 估价" + price ;
		}
	}
	
	private ArrayList<anime3> animeList = new ArrayList<>();
	private String name;
	private String num;
	private int price;
	boolean inName = false;
	boolean filter = true;
	
    @Override
    public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
    	if (inName) {
    		name = new String(arg0, arg1, arg2);
    	}
    }
 
    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }
    
    @Override
    public void endDocument() throws SAXException {
    	super.endDocument();
    	anime3[] animes = animeList.toArray(new anime3[animeList.size()]);
    	Arrays.sort(animes);
    	for(int i = 0; i < animes.length; i++) {
			System.out.println(i+1 + "." + animes[i]);
		}
    }
 
    @Override
    public void startElement(String arg0, String arg1, String arg2,
            Attributes arg3) throws SAXException {
    	if (arg2 == "seasons") {
    		int current = Integer.valueOf(arg3.getValue("current_season"));
    		filter = current > 1;
    	}
    	if (arg2 == "price") {
        	int num = Integer.valueOf(arg3.getValue("estimated_cost"));
        	price = price >= 0 ? Math.min(price, num) : num;
        }
        if (arg2 == "name" && (arg3.getLength() == 0 || arg3.getValue("language").equals("Chinese"))) {
        	inName = true;
        }
        super.startElement(arg0, arg1, arg2, arg3);
    }
    
    @Override
    public void endElement(String arg0, String arg1, String arg2)
            throws SAXException {
    	if (inName) {
			inName = !inName;
		}
    	if (arg2 == "anime") {
    		if (filter) {
    			anime3 anime = new anime3(name, price);
    			animeList.add(anime);
    		}
    		price = -1;
    	}
        super.endElement(arg0, arg1, arg2);
    }
}