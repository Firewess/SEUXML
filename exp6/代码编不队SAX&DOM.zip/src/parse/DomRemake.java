package parse;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DomRemake {
	public static void domRemake(String path) throws Exception  {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        File f = new File(path);
        Document doc = builder.parse(f);
        Node al = doc.getElementsByTagName("animeList").item(0);
        Document ndoc = builder.newDocument();
        Element animeList = (Element)ndoc.importNode(al, true);
        Element episode_left = ndoc.createElement("episode_left");
        Element overHalt = ndoc.createElement("overHalt");
        Element overQuarter = ndoc.createElement("overQuarter");
        Element underQuarter = ndoc.createElement("underQuarter");
        Element unknown = ndoc.createElement("unknown");
        
        NodeList animes = animeList.getElementsByTagName("anime");
        for (int i = 0; i < animes.getLength(); i++) {
            Element n = (Element)animes.item(i);
            //new doc
            Element anime = ndoc.createElement("anime");
            Element name = (Element)n.getElementsByTagName("name").item(0);
            Element type = (Element)n.getElementsByTagName("type").item(0);
            Element description = (Element)n.getElementsByTagName("description").item(0);
            Element details = ndoc.createElement("details");
            details.appendChild(type);
            details.appendChild(description);
            anime.appendChild(name);
            anime.appendChild(details);
            //old doc
            String episode_num = n.getAttribute("episode_num");
            int current = Integer.valueOf(((Element)n.getElementsByTagName("episode_list").item(0)).getAttribute("current_episode"));
            if(episode_num.equals("unknown")) {
            	unknown.appendChild(anime);
            } else if (Integer.valueOf(episode_num)>=2*current) {
				overHalt.appendChild(anime);
			} else if (3*Integer.valueOf(episode_num)>=4*current) {
				overQuarter.appendChild(anime);
			} else {
				underQuarter.appendChild(anime);
			}            
        }
        
        episode_left.appendChild(overHalt);
        episode_left.appendChild(overQuarter);
        episode_left.appendChild(underQuarter);
        episode_left.appendChild(unknown);
        
        ndoc.appendChild(episode_left);
        
        TransformerFactory tff = TransformerFactory.newInstance();
        Transformer tf = tff.newTransformer();
        tf.transform(new DOMSource(ndoc, "UTF-8"), new StreamResult(System.out));
	}
}
