package parse;

import java.util.ArrayList;
import java.util.Arrays;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class SaxHandler2 extends DefaultHandler {	
	class anime2 implements Comparable{
		String name;
		String num;
		anime2(String x, String y){
			this.name = x;
			this.num = y;
		}
		@Override
		public int compareTo(Object o) {
			anime2 obj = (anime2) o;
			return num.compareTo(obj.num);
		}
		public String toString(){
			return name + " : 集数" + ((num.equals("unknown"))?"未知":num) ;
		}
	}
	
	private ArrayList<anime2> animeList = new ArrayList<>();
	private String num;
	boolean inName = false;
	
    @Override
    public void characters(char[] arg0, int arg1, int arg2) throws SAXException {
    	if (inName) {
    		String name = new String(arg0, arg1, arg2);
    		anime2 anime = new anime2(name, num);
    		animeList.add(anime);
    	}
    }
 
    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }
    
    @Override
    public void endDocument() throws SAXException {
    	super.endDocument();
    	anime2[] animes = animeList.toArray(new anime2[animeList.size()]);
    	Arrays.sort(animes);
    	for(int i = 0; i < animes.length; i++) {
			System.out.println(i+1 + "." + animes[i]);
		}
    }
 
    @Override
    public void startElement(String arg0, String arg1, String arg2,
            Attributes arg3) throws SAXException {
    	if (arg2 == "anime") {
        	num = arg3.getValue("episode_num");
        }
        if (arg2 == "name" && (arg3.getLength() == 0 || arg3.getValue("language").equals("Chinese"))) {
        	inName = true;
        }
        super.startElement(arg0, arg1, arg2, arg3);
    }
    
    @Override
    public void endElement(String arg0, String arg1, String arg2)
            throws SAXException {
    	if (inName) {
			inName = !inName;
		}
        super.endElement(arg0, arg1, arg2);
    }
}